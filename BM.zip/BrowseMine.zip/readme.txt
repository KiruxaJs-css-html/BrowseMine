eng:

TO START THE GAME, YOU NEED TO RUN A FILE NAMED: index.html

rus:

ЧТОБЫ ЗАПУСТИТЬ ИГРУ НАДО ЗАПУСТЬ ФАЙЛ С ИМЕНЕМ: index.html
